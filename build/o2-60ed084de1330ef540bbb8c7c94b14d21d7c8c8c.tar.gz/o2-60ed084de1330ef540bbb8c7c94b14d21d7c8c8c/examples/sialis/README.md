# Sialis

Twitter demo for O2, demonstrating authenticating with Twitter and signing requests in order to show tweets.


