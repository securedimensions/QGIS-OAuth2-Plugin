//
// Created by michaelpollind on 3/13/17.
//

#ifndef O2_O2GOOGLE_H
#define O2_O2GOOGLE_H


class O2Google : public O2 {
    Q_OBJECT
public:
    explicit O2Google(QObject *parent = 0);
};


#endif //O2_O2GOOGLE_H
